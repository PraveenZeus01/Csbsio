// ── PATIENT LIST / TABLE ──

function renderPatients() {
  ptFiltered = patients.slice(); // reset to all
  ptPage = 1;
  document.getElementById('pt-search').value = '';
  document.getElementById('pt-filter').value = '';
  renderPtTable();
}

function filterPatients(query) {
  var status = document.getElementById('pt-filter').value;
  query = (query || '').toLowerCase();

  ptFiltered = patients.filter(function(p) {
    var matchesQuery = !query ||
      p.id.toLowerCase().includes(query) ||
      p.name.toLowerCase().includes(query) ||
      p.room.toLowerCase().includes(query) ||
      p.docName.toLowerCase().includes(query);
    var matchesStatus = !status || p.status === status;
    return matchesQuery && matchesStatus;
  });

  ptPage = 1;
  renderPtTable();
}

function renderPtTable() {
  var start = (ptPage - 1) * ptPerPage;
  var rows  = ptFiltered.slice(start, start + ptPerPage);
  var tbody = document.getElementById('pt-tbody');

  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="9"><div class="empty-state"><div class="icon">📋</div><p>No patients found.</p></div></td></tr>';
  } else {
    tbody.innerHTML = rows.map(function(p) {
      var statusBadge = p.status === 'active'
        ? '<span class="badge badge-green">Active</span>'
        : '<span class="badge badge-amber">Discharged</span>';
      return '<tr>' +
        '<td><b>' + p.id + '</b></td>' +
        '<td>' + p.name + '</td>' +
        '<td>' + p.age + ' / ' + p.gender + '</td>' +
        '<td>' + p.room + '</td>' +
        '<td>' + p.docName + '</td>' +
        '<td><span class="badge badge-red">' + p.blood + '</span></td>' +
        '<td>' + p.contact + '</td>' +
        '<td>' + statusBadge + '</td>' +
        '<td style="white-space:nowrap">' +
          '<button class="btn btn-outline btn-sm" onclick="viewPatient(\'' + p.id + '\')">View</button> ' +
          '<button class="btn btn-blue btn-sm"    onclick="openEditModal(\'' + p.id + '\')">Edit</button> ' +
          '<button class="btn btn-red btn-sm"     onclick="confirmDelete(\'' + p.id + '\')">Delete</button>' +
        '</td>' +
      '</tr>';
    }).join('');
  }
  renderPagination();
}

function renderPagination() {
  var total = Math.ceil(ptFiltered.length / ptPerPage);
  var el    = document.getElementById('pt-pagination');
  if (total <= 1) { el.innerHTML = ''; return; }

  var html = '<button class="pg-btn" onclick="goPage(' + (ptPage - 1) + ')" ' + (ptPage === 1 ? 'disabled' : '') + '>‹ Prev</button>';
  for (var i = 1; i <= total; i++) {
    html += '<button class="pg-btn' + (i === ptPage ? ' active' : '') + '" onclick="goPage(' + i + ')">' + i + '</button>';
  }
  html += '<button class="pg-btn" onclick="goPage(' + (ptPage + 1) + ')" ' + (ptPage === total ? 'disabled' : '') + '>Next ›</button>';
  el.innerHTML = html;
}

function goPage(n) {
  var total = Math.ceil(ptFiltered.length / ptPerPage);
  if (n < 1 || n > total) return;
  ptPage = n;
  renderPtTable();
}

// ── ADD / EDIT MODAL ──

function genId() {
  return 'P' + String(nextId).padStart(4, '0');
}

function openAddModal() {
  editingId = null;
  document.getElementById('modal-title').textContent    = 'Add New Patient';
  document.getElementById('modal-save-btn').textContent = 'Add Patient';

  // Clear all form fields
  ['pid','name','age','gender','weight','height','blood','contact','room','docid','docname','address'].forEach(function(f) {
    document.getElementById('f-' + f).value = '';
  });
  document.getElementById('f-status').value = 'active';
  document.getElementById('f-pid').value    = genId();

  openModal('patient-modal');
}

function openEditModal(id) {
  var p = patients.find(function(x) { return x.id === id; });
  if (!p) return;

  editingId = id;
  document.getElementById('modal-title').textContent    = 'Edit Patient — ' + id;
  document.getElementById('modal-save-btn').textContent = 'Save Changes';

  // Populate fields from patient data
  document.getElementById('f-pid').value     = p.id;
  document.getElementById('f-name').value    = p.name;
  document.getElementById('f-age').value     = p.age;
  document.getElementById('f-gender').value  = p.gender;
  document.getElementById('f-weight').value  = p.weight;
  document.getElementById('f-height').value  = p.height;
  document.getElementById('f-blood').value   = p.blood;
  document.getElementById('f-contact').value = p.contact;
  document.getElementById('f-room').value    = p.room;
  document.getElementById('f-docid').value   = p.docId;
  document.getElementById('f-docname').value = p.docName;
  document.getElementById('f-address').value = p.address;
  document.getElementById('f-status').value  = p.status;

  openModal('patient-modal');
}

function savePatient() {
  // Read form values
  var name    = document.getElementById('f-name').value.trim();
  var age     = document.getElementById('f-age').value;
  var gender  = document.getElementById('f-gender').value;
  var weight  = document.getElementById('f-weight').value;
  var height  = document.getElementById('f-height').value;
  var blood   = document.getElementById('f-blood').value;
  var contact = document.getElementById('f-contact').value.trim();
  var room    = document.getElementById('f-room').value.trim();
  var docId   = document.getElementById('f-docid').value.trim();
  var docName = document.getElementById('f-docname').value.trim();
  var address = document.getElementById('f-address').value.trim();
  var status  = document.getElementById('f-status').value;

  // Validation
  if (!name)                                   { toast('Patient name is required', 'error'); return; }
  if (!age || age < 0 || age > 120)            { toast('Enter a valid age (0–120)', 'error'); return; }
  if (!gender)                                 { toast('Select gender', 'error'); return; }
  if (!blood)                                  { toast('Select blood group', 'error'); return; }
  if (!contact || !/^\d{10}$/.test(contact))  { toast('Enter a valid 10-digit contact number', 'error'); return; }
  if (!room)                                   { toast('Room number is required', 'error'); return; }
  if (!docId)                                  { toast('Doctor ID is required', 'error'); return; }
  if (!docName)                                { toast('Doctor name is required', 'error'); return; }
  if (!address)                                { toast('Address is required', 'error'); return; }

  var record = {
    name: name, age: parseInt(age), gender: gender,
    weight: parseFloat(weight) || 0, height: parseFloat(height) || 0,
    blood: blood, contact: contact, room: room,
    docId: docId, docName: docName, address: address, status: status
  };

  if (editingId) {
    // Update existing
    var idx = patients.findIndex(function(x) { return x.id === editingId; });
    patients[idx] = Object.assign(patients[idx], record);
    toast('Patient updated successfully', 'success');
  } else {
    // Add new
    record.id = genId();
    patients.push(record);
    nextId++;
    toast('Patient ' + record.id + ' added successfully', 'success');
  }

  closeModal('patient-modal');
  renderPatients();
  renderDashboard();
}

// ── VIEW PATIENT MODAL ──

function viewPatient(id) {
  var p = patients.find(function(x) { return x.id === id; });
  if (!p) return;

  var fields = [
    ['Patient ID',   p.id],
    ['Full Name',    p.name],
    ['Age',          p.age + ' years'],
    ['Gender',       p.gender],
    ['Weight',       p.weight + ' kg'],
    ['Height',       p.height + ' cm'],
    ['Blood Group',  p.blood],
    ['Contact',      p.contact],
    ['Room',         p.room],
    ['Doctor ID',    p.docId],
    ['Doctor Name',  p.docName],
    ['Status',       p.status === 'active' ? 'Active (Admitted)' : 'Discharged'],
    ['Address',      p.address, 'full']
  ];

  var html = '<div class="form-row">';
  fields.forEach(function(f) {
    html += '<div class="form-field' + (f[2] ? ' field-full' : '') + '">' +
              '<label>' + f[0] + '</label>' +
              '<input readonly value="' + f[1] + '"/>' +
            '</div>';
  });
  html += '</div>';

  document.getElementById('view-modal-body').innerHTML = html;
  document.getElementById('view-edit-btn').onclick = function() {
    closeModal('view-modal');
    openEditModal(id);
  };
  openModal('view-modal');
}

// ── DELETE ──

function confirmDelete(id) {
  var p = patients.find(function(x) { return x.id === id; });
  deleteTargetId = id;
  document.getElementById('confirm-text').textContent =
    'You are about to delete the record for ' + p.name + ' (' + id + '). This cannot be undone.';
  document.getElementById('confirm-delete-btn').onclick = doDelete;
  openModal('confirm-modal');
}

function doDelete() {
  patients = patients.filter(function(x) { return x.id !== deleteTargetId; });
  toast('Patient record deleted', 'info');
  closeModal('confirm-modal');
  renderPatients();
  renderDashboard();
}
