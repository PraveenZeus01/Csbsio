// ===== SAMPLE DATA (loaded once, then saved to localStorage) =====
var defaultPatients = [
  { id:"P0001", name:"Ravi Kumar",  age:45, gender:"Male",   blood:"B+",  contact:"9841001001", room:"101A", doctor:"Dr. Ananya Sharma", status:"active" },
  { id:"P0002", name:"Meena Devi",  age:32, gender:"Female", blood:"O+",  contact:"9841002002", room:"102B", doctor:"Dr. Suresh Rajan",  status:"active" },
  { id:"P0003", name:"Arun Balaji", age:28, gender:"Male",   blood:"A+",  contact:"9841003003", room:"103C", doctor:"Dr. Ananya Sharma", status:"discharged" }
];

var patients = JSON.parse(localStorage.getItem("patients")) || defaultPatients;
var editId = null; // patient id currently being edited (null = adding new)

function save() {
  localStorage.setItem("patients", JSON.stringify(patients));
}

// ===== LOGIN =====
function login() {
  var user = document.getElementById("loginUser").value.trim();
  var pass = document.getElementById("loginPass").value.trim();

  if (user === "ADM00001" && pass === "Admin@12345") {
    document.getElementById("loginPage").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    showPage("dashboard");
  } else {
    alert("Invalid login. Use ADM00001 / Admin@12345");
  }
}

function logout() {
  document.getElementById("loginPage").classList.remove("hidden");
  document.getElementById("app").classList.add("hidden");
}

// ===== PAGE SWITCHING =====
function showPage(name) {
  var pages = ["dashboard", "patients", "formBox", "search", "billing"];
  for (var i = 0; i < pages.length; i++) {
    document.getElementById(pages[i]).classList.add("hidden");
  }
  document.getElementById(name).classList.remove("hidden");

  if (name === "dashboard") renderDashboard();
  if (name === "patients") renderPatients();
}

// ===== DASHBOARD =====
function renderDashboard() {
  var active = patients.filter(function(p) { return p.status === "active"; });
  document.getElementById("statTotal").textContent = patients.length;
  document.getElementById("statActive").textContent = active.length;
  document.getElementById("statDischarged").textContent = patients.length - active.length;

  var rows = "";
  patients.slice(-5).reverse().forEach(function(p) {
    rows += "<tr><td>" + p.id + "</td><td>" + p.name + "</td><td>" + p.room +
            "</td><td>" + p.doctor + "</td><td class='" + p.status + "'>" + p.status + "</td></tr>";
  });
  document.getElementById("recentTable").innerHTML = rows;
}

// ===== PATIENTS LIST =====
function renderPatients() {
  var query = (document.getElementById("searchBox").value || "").toLowerCase();
  var rows = "";

  patients.forEach(function(p) {
    if (query && p.name.toLowerCase().indexOf(query) === -1 && p.id.toLowerCase().indexOf(query) === -1) {
      return; // skip if doesn't match search
    }
    rows += "<tr><td>" + p.id + "</td><td>" + p.name + "</td><td>" + p.age + "</td><td>" + p.room +
            "</td><td>" + p.doctor + "</td><td>" + p.blood + "</td><td class='" + p.status + "'>" + p.status + "</td>" +
            "<td>" +
              "<button onclick=\"openForm('" + p.id + "')\">Edit</button>" +
              "<button onclick=\"deletePatient('" + p.id + "')\">Delete</button>" +
            "</td></tr>";
  });
  document.getElementById("patientTable").innerHTML = rows;
}

// ===== ADD / EDIT FORM =====
function openForm(id) {
  editId = id || null;
  var p = patients.find(function(x) { return x.id === id; });

  document.getElementById("formTitle").textContent = p ? "Edit Patient" : "Add Patient";
  document.getElementById("fName").value = p ? p.name : "";
  document.getElementById("fAge").value = p ? p.age : "";
  document.getElementById("fGender").value = p ? p.gender : "";
  document.getElementById("fBlood").value = p ? p.blood : "";
  document.getElementById("fContact").value = p ? p.contact : "";
  document.getElementById("fRoom").value = p ? p.room : "";
  document.getElementById("fDoctor").value = p ? p.doctor : "";
  document.getElementById("fStatus").value = p ? p.status : "active";

  showPage("formBox");
}

function savePatient() {
  var name = document.getElementById("fName").value.trim();
  if (!name) { alert("Name is required"); return; }

  var data = {
    name: name,
    age: document.getElementById("fAge").value,
    gender: document.getElementById("fGender").value,
    blood: document.getElementById("fBlood").value,
    contact: document.getElementById("fContact").value,
    room: document.getElementById("fRoom").value,
    doctor: document.getElementById("fDoctor").value,
    status: document.getElementById("fStatus").value
  };

  if (editId) {
    var p = patients.find(function(x) { return x.id === editId; });
    Object.assign(p, data);
  } else {
    data.id = "P" + String(patients.length + 1).padStart(4, "0");
    patients.push(data);
  }

  save();
  showPage("patients");
}

function deletePatient(id) {
  if (!confirm("Delete this patient record?")) return;
  patients = patients.filter(function(p) { return p.id !== id; });
  save();
  renderPatients();
}

// ===== SEARCH =====
function searchPatient() {
  var id = document.getElementById("searchId").value.trim().toUpperCase();
  var p = patients.find(function(x) { return x.id === id; });
  var box = document.getElementById("searchResult");

  if (!p) {
    box.innerHTML = "<p>No patient found with ID: " + id + "</p>";
    return;
  }
  box.innerHTML =
    "<table>" +
    "<tr><th>Name</th><td>" + p.name + "</td></tr>" +
    "<tr><th>Age</th><td>" + p.age + "</td></tr>" +
    "<tr><th>Gender</th><td>" + p.gender + "</td></tr>" +
    "<tr><th>Blood Group</th><td>" + p.blood + "</td></tr>" +
    "<tr><th>Contact</th><td>" + p.contact + "</td></tr>" +
    "<tr><th>Room</th><td>" + p.room + "</td></tr>" +
    "<tr><th>Doctor</th><td>" + p.doctor + "</td></tr>" +
    "<tr><th>Status</th><td class='" + p.status + "'>" + p.status + "</td></tr>" +
    "</table>";
}

// ===== BILLING =====
var billPatient = null;

function loadBill() {
  var id = document.getElementById("billId").value.trim().toUpperCase();
  var p = patients.find(function(x) { return x.id === id; });

  if (!p) { alert("No patient found with ID: " + id); return; }

  billPatient = p;
  document.getElementById("billName").textContent = p.name + " (" + p.id + ")";
  document.getElementById("billBox").classList.remove("hidden");
  calcBill();
}

function calcBill() {
  var rate = Number(document.getElementById("roomRate").value) || 0;
  var days = Number(document.getElementById("days").value) || 0;
  var pharmacy = Number(document.getElementById("pharmacy").value) || 0;
  var diagnostics = Number(document.getElementById("diagnostics").value) || 0;

  var total = (rate * days) + pharmacy + diagnostics;
  document.getElementById("billTotal").textContent = total;
}
