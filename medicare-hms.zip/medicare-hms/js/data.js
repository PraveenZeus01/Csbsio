// ── SAMPLE DATA ──
var patients = [
  { id:'P0001', name:'Ravi Kumar',      age:45, gender:'Male',   weight:72, height:170, blood:'B+',  contact:'9841001001', room:'101A', docId:'D001', docName:'Dr. Ananya Sharma',  address:'12, Anna Nagar, Chennai',      status:'active' },
  { id:'P0002', name:'Meena Devi',      age:32, gender:'Female', weight:58, height:162, blood:'O+',  contact:'9841002002', room:'102B', docId:'D002', docName:'Dr. Suresh Rajan',   address:'45, T Nagar, Chennai',         status:'active' },
  { id:'P0003', name:'Arun Balaji',     age:28, gender:'Male',   weight:80, height:178, blood:'A+',  contact:'9841003003', room:'103C', docId:'D001', docName:'Dr. Ananya Sharma',  address:'78, Adyar, Chennai',           status:'active' },
  { id:'P0004', name:'Priya Nair',      age:55, gender:'Female', weight:65, height:158, blood:'AB+', contact:'9841004004', room:'201A', docId:'D003', docName:'Dr. Kavitha Menon',  address:'23, Velachery, Chennai',       status:'active' },
  { id:'P0005', name:'Suresh Babu',     age:62, gender:'Male',   weight:88, height:172, blood:'O-',  contact:'9841005005', room:'201B', docId:'D003', docName:'Dr. Kavitha Menon',  address:'10, Porur, Chennai',           status:'discharged' },
  { id:'P0006', name:'Lakshmi Iyer',    age:40, gender:'Female', weight:61, height:160, blood:'B-',  contact:'9841006006', room:'202A', docId:'D002', docName:'Dr. Suresh Rajan',   address:'55, Mylapore, Chennai',        status:'active' },
  { id:'P0007', name:'Kartik Sundaram', age:19, gender:'Male',   weight:68, height:180, blood:'A-',  contact:'9841007007', room:'301A', docId:'D004', docName:'Dr. Vijay Prakash',  address:'88, Guindy, Chennai',          status:'active' },
  { id:'P0008', name:'Divya Krishnan',  age:37, gender:'Female', weight:55, height:155, blood:'AB-', contact:'9841008008', room:'301B', docId:'D004', docName:'Dr. Vijay Prakash',  address:'34, Tambaram, Chennai',        status:'active' },
  { id:'P0009', name:'Muthukumar P',    age:70, gender:'Male',   weight:75, height:165, blood:'O+',  contact:'9841009009', room:'302A', docId:'D001', docName:'Dr. Ananya Sharma',  address:'67, Chromepet, Chennai',       status:'active' },
  { id:'P0010', name:'Revathi S',       age:48, gender:'Female', weight:63, height:163, blood:'B+',  contact:'9841010010', room:'302B', docId:'D002', docName:'Dr. Suresh Rajan',   address:'90, Sholinganallur, Chennai',  status:'discharged' },
];

// ── APP STATE ──
var nextId        = 11;       // next patient number
var currentUser   = null;     // logged-in user ID
var editingId     = null;     // patient being edited (null = new)
var deleteTargetId = null;    // patient queued for deletion
var billPatient   = null;     // patient loaded in billing
var searchPatient = null;     // patient found in search

// ── PAGINATION STATE ──
var ptPage     = 1;
var ptPerPage  = 6;
var ptFiltered = [];          // current filtered list shown in table
