// ── TOAST NOTIFICATIONS ──
function toast(msg, type) {
  var el = document.createElement('div');
  el.className = 'toast-msg toast-' + (type || 'info');
  el.textContent = msg;
  document.getElementById('toast').appendChild(el);
  setTimeout(function() { el.classList.add('show'); }, 10);
  setTimeout(function() {
    el.classList.remove('show');
    setTimeout(function() { el.remove(); }, 400);
  }, 3200);
}

// ── MODAL HELPERS ──
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// Close modal when clicking the dark overlay
document.querySelectorAll('.modal-overlay').forEach(function(overlay) {
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

// ── NAVIGATION ──
function showSection(id, btn) {
  // Hide all sections and deactivate all nav buttons
  document.querySelectorAll('.section').forEach(function(s) { s.classList.remove('active'); });
  document.querySelectorAll('.nav-btn').forEach(function(b)  { b.classList.remove('active'); });

  // Show the selected section
  document.getElementById('sec-' + id).classList.add('active');
  if (btn) btn.classList.add('active');

  // Refresh data when switching tabs
  if (id === 'dashboard') renderDashboard();
  if (id === 'patients')  renderPatients();
}
