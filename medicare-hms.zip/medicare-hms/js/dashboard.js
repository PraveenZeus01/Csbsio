// ── DASHBOARD ──
function renderDashboard() {
  var active = patients.filter(function(p) { return p.status === 'active'; });
  var rooms  = new Set(active.map(function(p) { return p.room; })).size;

  document.getElementById('d-total').textContent  = patients.length;
  document.getElementById('d-active').textContent = active.length;
  document.getElementById('d-rooms').textContent  = rooms;
  document.getElementById('d-bills').textContent  = active.length; // pending bills = active patients

  // Show last 5 patients (most recent first)
  var recent = patients.slice(-5).reverse();
  document.getElementById('dash-recent').innerHTML = recent.map(function(p) {
    var statusBadge = p.status === 'active'
      ? '<span class="badge badge-green">Active</span>'
      : '<span class="badge badge-amber">Discharged</span>';
    return '<tr>' +
      '<td><b>' + p.id + '</b></td>' +
      '<td>' + p.name + '</td>' +
      '<td>' + p.room + '</td>' +
      '<td>' + p.docName + '</td>' +
      '<td><span class="badge badge-red">' + p.blood + '</span></td>' +
      '<td>' + statusBadge + '</td>' +
    '</tr>';
  }).join('');
}
