// ── AUTH ──

// Validation helpers
function validateUid(u) {
  return /^[a-zA-Z0-9]{8,}$/.test(u);
}
function validatePwd(p) {
  return p.length >= 10 && /[A-Z]/.test(p) && /[0-9]/.test(p) && /[^a-zA-Z0-9]/.test(p);
}

function doLogin() {
  var uid = document.getElementById('login-uid').value.trim();
  var pwd = document.getElementById('login-pwd').value;

  if (!validateUid(uid)) {
    toast('User ID must be alphanumeric with at least 8 characters', 'error');
    return;
  }
  if (!validatePwd(pwd)) {
    toast('Password must be 10+ chars with uppercase, number and special character', 'error');
    return;
  }

  // Credential check (demo: hardcoded)
  if (uid === 'ADM00001' && pwd === 'Admin@12345') {
    currentUser = uid;
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
    document.getElementById('nav-username').textContent = uid;
    document.getElementById('nav-avatar').textContent   = uid[0].toUpperCase();
    document.getElementById('dash-name').textContent    = uid;
    renderDashboard();
    renderPatients();
    toast('Welcome back, ' + uid + '!', 'success');
  } else {
    toast('Invalid credentials. Please try again.', 'error');
  }
}

function doLogout() {
  currentUser = null;
  document.getElementById('login-page').style.display = 'flex';
  document.getElementById('app').style.display = 'none';
  document.getElementById('login-uid').value = '';
  document.getElementById('login-pwd').value = '';
  toast('Signed out successfully', 'info');
}

// Allow Enter key to submit login form
document.getElementById('login-uid').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') document.getElementById('login-pwd').focus();
});
document.getElementById('login-pwd').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') doLogin();
});
