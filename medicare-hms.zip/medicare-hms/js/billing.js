// ── BILLING ──

function loadBilling() {
  var id = document.getElementById('bill-pid').value.trim().toUpperCase();
  if (!id) { toast('Enter a patient ID', 'error'); return; }

  var p = patients.find(function(x) { return x.id === id; });
  if (!p) {
    toast('No patient found with ID: ' + id, 'error');
    document.getElementById('bill-card').style.display = 'none';
    return;
  }

  billPatient = p;
  document.getElementById('bill-pname').textContent      = p.name;
  document.getElementById('bill-pid-display').textContent = p.id;
  document.getElementById('bill-doctor').textContent      = p.docName;

  // Reset inputs to defaults
  document.getElementById('b-room-rate').value  = 2000;
  document.getElementById('b-days').value        = 3;
  document.getElementById('b-pharmacy').value    = 0;
  document.getElementById('b-diagnostics').value = 0;

  document.getElementById('bill-card').style.display = 'block';
  calcBill();
  toast('Patient loaded: ' + p.name, 'success');
}

function calcBill() {
  var rate   = parseFloat(document.getElementById('b-room-rate').value)  || 0;
  var days   = parseFloat(document.getElementById('b-days').value)       || 0;
  var pharma = parseFloat(document.getElementById('b-pharmacy').value)   || 0;
  var diag   = parseFloat(document.getElementById('b-diagnostics').value)|| 0;

  var roomTotal = rate * days;
  var total     = roomTotal + pharma + diag;

  document.getElementById('bill-room-amt').textContent  = '₹' + roomTotal.toLocaleString('en-IN');
  document.getElementById('bill-pharma-amt').textContent = '₹' + pharma.toLocaleString('en-IN');
  document.getElementById('bill-diag-amt').textContent  = '₹' + diag.toLocaleString('en-IN');
  document.getElementById('bill-total-amt').textContent = '₹' + total.toLocaleString('en-IN');
}

function printBill() {
  window.print();
}

function clearBilling() {
  document.getElementById('bill-pid').value = '';
  document.getElementById('bill-card').style.display = 'none';
  billPatient = null;
}
