// ── LOCAL PERSISTENCE ──
// Keeps patient records in the browser (localStorage) so data survives
// a page refresh. Pure client-side — no server, no network calls.

var STORAGE_KEY = 'medicare_hms_patients';
var STORAGE_NEXTID_KEY = 'medicare_hms_nextid';

function loadFromStorage() {
  try {
    var saved = localStorage.getItem(STORAGE_KEY);
    var savedNextId = localStorage.getItem(STORAGE_NEXTID_KEY);
    if (saved) {
      patients = JSON.parse(saved);
    }
    if (savedNextId) {
      nextId = parseInt(savedNextId, 10);
    }
  } catch (e) {
    console.warn('Could not load saved patient data, using sample data instead.', e);
  }
}

function saveToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(patients));
    localStorage.setItem(STORAGE_NEXTID_KEY, String(nextId));
  } catch (e) {
    console.warn('Could not save patient data.', e);
  }
}

function resetSampleData() {
  localStorage.removeItem(STORAGE_KEY);
  localStorage.removeItem(STORAGE_NEXTID_KEY);
  location.reload();
}

// Load any previously saved data right away, before the rest of the app renders.
loadFromStorage();
