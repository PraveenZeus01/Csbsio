// ── PATIENT SEARCH ──

function doSearch() {
  var id = document.getElementById('srch-id').value.trim().toUpperCase();
  if (!id) { toast('Enter a patient ID to search', 'error'); return; }

  var p = patients.find(function(x) { return x.id === id; });

  // Hide previous results
  document.getElementById('search-result').style.display = 'none';
  document.getElementById('search-empty').style.display  = 'none';

  if (!p) {
    document.getElementById('search-empty').style.display = 'block';
    toast('No patient found with ID: ' + id, 'error');
    return;
  }

  searchPatient = p;

  // Fill the result card header
  document.getElementById('sr-avatar').textContent = p.name[0];
  document.getElementById('sr-name').textContent   = p.name;
  document.getElementById('sr-id').textContent     = 'ID: ' + p.id + ' · Room: ' + p.room + ' · ' + (p.status === 'active' ? 'Active' : 'Discharged');

  // Fill the detail grid
  var fields = [
    ['Age',         p.age + ' years'],
    ['Gender',      p.gender],
    ['Blood Group', p.blood],
    ['Contact',     p.contact],
    ['Weight',      p.weight + ' kg'],
    ['Height',      p.height + ' cm'],
    ['Room',        p.room],
    ['Doctor ID',   p.docId],
    ['Doctor Name', p.docName],
    ['Address',     p.address],
    ['Status',      p.status === 'active' ? 'Active' : 'Discharged']
  ];
  document.getElementById('sr-details').innerHTML = fields.map(function(f) {
    return '<div class="detail-item"><div class="key">' + f[0] + '</div><div class="val">' + f[1] + '</div></div>';
  }).join('');

  document.getElementById('search-result').style.display = 'block';
  toast('Patient found: ' + p.name, 'success');
}

function clearSearch() {
  document.getElementById('srch-id').value = '';
  document.getElementById('search-result').style.display = 'none';
  document.getElementById('search-empty').style.display  = 'none';
  searchPatient = null;
}

function editFromSearch() {
  if (searchPatient) {
    showSection('patients', document.querySelector('.nav-btn:nth-child(3)'));
    openEditModal(searchPatient.id);
  }
}

function billFromSearch() {
  if (searchPatient) {
    showSection('billing', document.querySelector('.nav-btn:nth-child(5)'));
    document.getElementById('bill-pid').value = searchPatient.id;
    loadBilling();
  }
}
