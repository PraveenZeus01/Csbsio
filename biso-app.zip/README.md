# BISO — H1 backlog system

A full-stack app for the H1 BISO backlog: 4 pages (Home, Dashboard, Backlog, Story detail),
backed by a real SQLite database through a REST API.

## Stack
- **Backend**: Node.js + Express, using Node's built-in `node:sqlite` module (no native
  compilation, no external DB server required).
- **Frontend**: plain HTML/CSS/JS, no build step. Clinical/SQL-style design system shared
  across all pages via `public/styles.css`.
- **Database**: `server/biso.db` — created and seeded automatically on first run.

## Setup

```bash
npm install
```

## Run

```bash
node server/index.js
```

Then open **http://localhost:3000** in a browser.

The server serves both the API and the static frontend on the same port, so there's
nothing else to start.

## Pages
- `/` — Home, overview and entry points
- `/dashboard.html` — live aggregate stats: status counts, points completion,
  sprint burndown, track breakdown
- `/backlog.html` — the full backlog table (ui_track + db_track), with status/track
  filters, pulled live from the database
- `/story.html?id=US001` — single story detail, with an edit panel that PATCHes
  status / priority / points / sprint back to the database

## API

| Method | Route                  | Description                                  |
|--------|------------------------|-----------------------------------------------|
| GET    | `/api/stories`         | All stories. Optional `?track=ui|db` and `?status=done|progress|blocked|backlog` |
| GET    | `/api/stories/:id`     | Single story by id                            |
| PATCH  | `/api/stories/:id`     | Update status, priority, points, sprint, title, or description |
| GET    | `/api/stats`           | Aggregate stats used by the dashboard         |

## Data model

Table `stories`:

| Column               | Type    | Notes                                      |
|-----------------------|---------|---------------------------------------------|
| id                    | TEXT    | primary key, e.g. `US001`, `US001-DB`       |
| track                 | TEXT    | `ui` or `db`                                |
| title                 | TEXT    |                                              |
| description           | TEXT    |                                              |
| acceptance_criteria   | TEXT    | stored as a JSON array string               |
| points                | INTEGER |                                              |
| priority              | TEXT    | `P1`, `P2`, or `P3`                         |
| sprint                | TEXT    | e.g. `Sprint 1`                             |
| status                | TEXT    | `done`, `progress`, `blocked`, or `backlog` |
| updated_at            | TEXT    | auto-updated on PATCH                       |

## Resetting the data

Delete `server/biso.db` and restart the server — it reseeds the 10 placeholder
stories (US001–US007 on `ui_track`, US001-DB–US003-DB on `db_track`) automatically.

## Notes

- `node:sqlite` is an experimental Node API (stable since Node 22). You'll see an
  `ExperimentalWarning` on startup — that's expected and harmless.
- All data is placeholder. Edit rows via the story detail page, or directly with
  `PATCH /api/stories/:id`, to replace it with your real backlog content.
