const { DatabaseSync } = require('node:sqlite');
const path = require('path');

const DB_PATH = path.join(__dirname, 'biso.db');
const db = new DatabaseSync(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS stories (
    id TEXT PRIMARY KEY,
    track TEXT NOT NULL CHECK(track IN ('ui','db')),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    acceptance_criteria TEXT NOT NULL,
    points INTEGER NOT NULL,
    priority TEXT NOT NULL CHECK(priority IN ('P1','P2','P3')),
    sprint TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('done','progress','blocked','backlog')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

function seedIfEmpty() {
  const count = db.prepare('SELECT COUNT(*) AS c FROM stories').get().c;
  if (count > 0) return;

  const seed = [
    {
      id: 'US001', track: 'ui', title: 'Patient lookup search bar',
      description: 'As a clinician, I want to search patients by MRN or name so I can open a chart quickly.',
      acceptance_criteria: JSON.stringify([
        'Returns results in < 1s for <=10k records',
        'Supports partial MRN match',
        'Shows "no results" empty state'
      ]),
      points: 5, priority: 'P1', sprint: 'Sprint 1', status: 'done'
    },
    {
      id: 'US002', track: 'ui', title: 'Vitals trend chart',
      description: 'As a nurse, I want a 24h vitals trend view so I can spot deterioration early.',
      acceptance_criteria: JSON.stringify([
        'Renders HR, BP, SpO2 on shared timeline',
        'Out-of-range values flagged in red',
        'Tooltip shows exact reading + timestamp'
      ]),
      points: 8, priority: 'P1', sprint: 'Sprint 1', status: 'progress'
    },
    {
      id: 'US003', track: 'ui', title: 'Medication order entry form',
      description: 'As a physician, I want a structured order form with dosage validation to reduce entry errors.',
      acceptance_criteria: JSON.stringify([
        'Blocks submission outside safe dosage range',
        'Requires route + frequency fields',
        'Logs order to audit table on submit'
      ]),
      points: 13, priority: 'P1', sprint: 'Sprint 2', status: 'blocked'
    },
    {
      id: 'US004', track: 'ui', title: 'Shift handoff summary panel',
      description: 'As a nurse, I want a condensed handoff summary per patient so shift changes are faster.',
      acceptance_criteria: JSON.stringify([
        'Summarizes last 12h events in <=5 lines',
        'Printable / exportable as PDF'
      ]),
      points: 5, priority: 'P2', sprint: 'Sprint 2', status: 'backlog'
    },
    {
      id: 'US005', track: 'ui', title: 'Role-based access toggle',
      description: 'As an admin, I want to restrict UI panels by role so unauthorized edits are prevented.',
      acceptance_criteria: JSON.stringify([
        'Read-only mode enforced for view-only roles',
        'Attempted writes return 403 + UI toast'
      ]),
      points: 8, priority: 'P2', sprint: 'Sprint 2', status: 'backlog'
    },
    {
      id: 'US006', track: 'ui', title: 'Lab result flag indicators',
      description: 'As a clinician, I want abnormal lab values visually flagged so I can triage faster.',
      acceptance_criteria: JSON.stringify([
        'High/low/critical flags styled distinctly',
        'Hover shows reference range'
      ]),
      points: 3, priority: 'P3', sprint: 'Sprint 3', status: 'backlog'
    },
    {
      id: 'US007', track: 'ui', title: 'Discharge checklist widget',
      description: 'As a case manager, I want a discharge readiness checklist so nothing is missed at sign-off.',
      acceptance_criteria: JSON.stringify([
        'All items must check before discharge button enables',
        'State persists across page reload'
      ]),
      points: 5, priority: 'P3', sprint: 'Sprint 3', status: 'backlog'
    },
    {
      id: 'US001-DB', track: 'db', title: 'Normalize patient_visits schema',
      description: 'As the platform, I need patient_visits normalized to 3NF so reporting joins stay performant.',
      acceptance_criteria: JSON.stringify([
        'No repeating groups in visit table',
        'FK constraints validated against patients',
        'Migration is reversible'
      ]),
      points: 8, priority: 'P1', sprint: 'Sprint 1', status: 'done'
    },
    {
      id: 'US002-DB', track: 'db', title: 'Audit log trigger for orders table',
      description: 'As compliance, I need every order mutation logged so we can reconstruct history for audits.',
      acceptance_criteria: JSON.stringify([
        'Trigger fires on INSERT/UPDATE/DELETE',
        'Captures actor_id, timestamp, diff',
        'No measurable write latency increase >5ms'
      ]),
      points: 13, priority: 'P1', sprint: 'Sprint 2', status: 'progress'
    },
    {
      id: 'US003-DB', track: 'db', title: 'Index optimization for vitals query',
      description: 'As the platform, I need composite indexing on vitals(patient_id, recorded_at) to support the trend chart.',
      acceptance_criteria: JSON.stringify([
        'Query plan shows index scan, not seq scan',
        'P95 query time < 150ms at current volume'
      ]),
      points: 5, priority: 'P2', sprint: 'Sprint 2', status: 'backlog'
    }
  ];

  const insert = db.prepare(`
    INSERT INTO stories (id, track, title, description, acceptance_criteria, points, priority, sprint, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const s of seed) {
    insert.run(s.id, s.track, s.title, s.description, s.acceptance_criteria, s.points, s.priority, s.sprint, s.status);
  }
  console.log(`Seeded ${seed.length} stories.`);
}

seedIfEmpty();

module.exports = db;
