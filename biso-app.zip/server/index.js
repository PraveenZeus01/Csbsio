const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

const VALID_STATUS = ['done', 'progress', 'blocked', 'backlog'];
const VALID_PRIORITY = ['P1', 'P2', 'P3'];
const VALID_TRACK = ['ui', 'db'];

function rowToStory(row) {
  return {
    ...row,
    acceptance_criteria: JSON.parse(row.acceptance_criteria)
  };
}

// GET /api/stories  -> all stories, optional ?track=ui|db &status=...
app.get('/api/stories', (req, res) => {
  const { track, status } = req.query;
  let sql = 'SELECT * FROM stories WHERE 1=1';
  const params = [];
  if (track) { sql += ' AND track = ?'; params.push(track); }
  if (status) { sql += ' AND status = ?'; params.push(status); }
  sql += ' ORDER BY track, id';
  const rows = db.prepare(sql).all(...params);
  res.json(rows.map(rowToStory));
});

// GET /api/stories/:id
app.get('/api/stories/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM stories WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Story not found' });
  res.json(rowToStory(row));
});

// PATCH /api/stories/:id -> update status / points / priority / sprint
app.patch('/api/stories/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM stories WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Story not found' });

  const { status, points, priority, sprint, title, description } = req.body;

  if (status !== undefined && !VALID_STATUS.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${VALID_STATUS.join(', ')}` });
  }
  if (priority !== undefined && !VALID_PRIORITY.includes(priority)) {
    return res.status(400).json({ error: `priority must be one of ${VALID_PRIORITY.join(', ')}` });
  }
  if (points !== undefined && (typeof points !== 'number' || points < 0)) {
    return res.status(400).json({ error: 'points must be a non-negative number' });
  }

  const next = {
    status: status ?? existing.status,
    points: points ?? existing.points,
    priority: priority ?? existing.priority,
    sprint: sprint ?? existing.sprint,
    title: title ?? existing.title,
    description: description ?? existing.description
  };

  db.prepare(`
    UPDATE stories
    SET status = ?, points = ?, priority = ?, sprint = ?, title = ?, description = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(next.status, next.points, next.priority, next.sprint, next.title, next.description, req.params.id);

  const updated = db.prepare('SELECT * FROM stories WHERE id = ?').get(req.params.id);
  res.json(rowToStory(updated));
});

// GET /api/stats -> dashboard aggregates
app.get('/api/stats', (req, res) => {
  const rows = db.prepare('SELECT * FROM stories').all();

  const totalStories = rows.length;
  const totalPoints = rows.reduce((sum, r) => sum + r.points, 0);
  const pointsByStatus = { done: 0, progress: 0, blocked: 0, backlog: 0 };
  const countByStatus = { done: 0, progress: 0, blocked: 0, backlog: 0 };

  for (const r of rows) {
    pointsByStatus[r.status] += r.points;
    countByStatus[r.status] += 1;
  }

  const sprintMap = {};
  for (const r of rows) {
    if (!sprintMap[r.sprint]) {
      sprintMap[r.sprint] = { sprint: r.sprint, total: 0, done: 0 };
    }
    sprintMap[r.sprint].total += r.points;
    if (r.status === 'done') sprintMap[r.sprint].done += r.points;
  }
  const sprints = Object.values(sprintMap).sort((a, b) => a.sprint.localeCompare(b.sprint));

  const trackMap = {};
  for (const r of rows) {
    if (!trackMap[r.track]) trackMap[r.track] = { track: r.track, total: 0, done: 0, count: 0 };
    trackMap[r.track].total += r.points;
    trackMap[r.track].count += 1;
    if (r.status === 'done') trackMap[r.track].done += r.points;
  }

  res.json({
    totalStories,
    totalPoints,
    pointsByStatus,
    countByStatus,
    completionRate: totalPoints > 0 ? Math.round((pointsByStatus.done / totalPoints) * 100) : 0,
    sprints,
    tracks: Object.values(trackMap)
  });
});

// Serve frontend
app.use(express.static(path.join(__dirname, '..', 'public')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`BISO backlog server running at http://localhost:${PORT}`);
});
